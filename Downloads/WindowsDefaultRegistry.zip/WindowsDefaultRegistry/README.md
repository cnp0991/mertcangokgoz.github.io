# Windows Default Registry For File Type Associations

This repo will reset the associations, icon, and registry entries of the downloaded file type or protocol back to default.

Require: Windows 7, 8, 8.1 and 10
